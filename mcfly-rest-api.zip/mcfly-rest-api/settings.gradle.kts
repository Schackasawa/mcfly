rootProject.name = "mcfly-rest-api"
