package com.schackasawa.mcflyrestapi

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class McflyRestApiApplicationTests {

	@Test
	fun contextLoads() {
	}

}
